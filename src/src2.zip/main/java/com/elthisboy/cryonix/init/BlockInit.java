package com.elthisboy.cryonix.init;

public class BlockInit {




    public static void load() {
    }
}
