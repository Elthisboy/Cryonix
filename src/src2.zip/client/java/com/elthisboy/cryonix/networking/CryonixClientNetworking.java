package com.elthisboy.cryonix.networking;

import com.elthisboy.cryonix.client.hud.ScanHudData;
import com.elthisboy.cryonix.networking.payload.ScanResultsPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

import com.elthisboy.cryonix.client.hud.ScanHudData;
import com.elthisboy.cryonix.networking.payload.ScanResultsPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public final class CryonixClientNetworking {

    private CryonixClientNetworking() {}

    /** Registra SOLO el handler del payload (el tipo debe estar registrado en común). */
    public static void initClient() {
        // Limpia el HUD al desconectar del servidor/mundo.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ScanHudData.clear());

        // Handler de resultados de escaneo (S2C)
        ClientPlayNetworking.registerGlobalReceiver(ScanResultsPayload.ID,
                (ScanResultsPayload payload, ClientPlayNetworking.Context ctx) ->
                        ctx.client().execute(() -> handleScanResults(payload)));
    }

    // === Helpers de íconos ===

    // Ícono de un bloque (ore) por su identifier. Fallback: STONE.
    private static ItemStack iconForBlockId(String blockIdStr) {
        try {
            Identifier id = Identifier.of(blockIdStr);
            var block = Registries.BLOCK.get(id);
            if (block != null) {
                Item item = block.asItem();
                if (item != null && item != Items.AIR) {
                    return new ItemStack(item);
                }
            }
        } catch (Exception ignored) {}
        return new ItemStack(Items.STONE);
    }

    // Busca un spawn egg que apunte al EntityType recorriendo el registro (compatible 1.21.1).
    private static ItemStack iconForEntityType(EntityType<?> type, boolean villager, boolean hostile) {
        if (type != null) {
            for (Item item : Registries.ITEM) {
                if (item instanceof SpawnEggItem egg) {
                    // En 1.21.1, getEntityType(RegistryEntryLookup) acepta null de forma segura en cliente.
                    if (egg.getEntityType(null) == type) {
                        return new ItemStack(egg);
                    }
                }
            }
        }
        // Fallbacks visuales por categoría
        if (villager)  return new ItemStack(Items.EMERALD);
        if (hostile)   return new ItemStack(Items.REDSTONE_TORCH);
        return new ItemStack(Items.WHEAT);
    }

    private static boolean isHostile(SpawnGroup group) {
        // Monsters y similares no son "peaceful".
        return group != null && !group.isPeaceful() && group != SpawnGroup.WATER_AMBIENT && group != SpawnGroup.AMBIENT;
    }

    // === Construye y envía al HUD ===
    private static void handleScanResults(ScanResultsPayload p) {
        List<ScanHudData.BlockEntry> blocks = new ArrayList<>();
        List<ScanHudData.MobEntry> mobs = new ArrayList<>();

        // Bloques/Ores
        for (int i = 0; i < p.blocksN().size(); i++) {
            String name = p.blocksN().get(i);
            double dist = p.blocksD().get(i);
            String idStr = (i < p.blocksId().size()) ? p.blocksId().get(i) : "minecraft:stone";
            ItemStack icon = iconForBlockId(idStr);
            blocks.add(new ScanHudData.BlockEntry(name, dist, icon));
        }

        // Mobs (con categorización y etiqueta de villager)
        for (int i = 0; i < p.mobsN().size(); i++) {
            String baseName = p.mobsN().get(i);
            double dist = p.mobsD().get(i);
            String idStr = (i < p.mobsId().size()) ? p.mobsId().get(i) : "minecraft:pig";

            Identifier id = Identifier.of(idStr);
            EntityType<?> type = Registries.ENTITY_TYPE.get(id);

            boolean villager = type == EntityType.VILLAGER;
            boolean hostile  = type != null && isHostile(type.getSpawnGroup());

            // Etiqueta final: para aldeano, asegúrate de que diga "Villager (Unemployed/...)"
            String label = baseName;
            if (villager) {
                String lower = baseName.toLowerCase();
                if (!lower.contains("villager")) {
                    label = "Villager (" + baseName + ")";
                }
            }

            int color = villager ? 0x00AAFF : (hostile ? 0xFF6B6B : 0x7CFFB2);
            ItemStack icon = (type != null) ? iconForEntityType(type, villager, hostile) : new ItemStack(Items.WHEAT);

            mobs.add(new ScanHudData.MobEntry(label, dist, icon, color));
        }

        boolean nothing = blocks.isEmpty() && mobs.isEmpty();
        ScanHudData.update(blocks, mobs, nothing);
    }
}